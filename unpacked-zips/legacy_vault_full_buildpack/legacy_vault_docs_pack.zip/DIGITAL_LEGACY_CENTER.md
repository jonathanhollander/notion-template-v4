# Digital Legacy Center (Sample)

⚠️ Disclaimer: SAMPLE ONLY. Each service may update policies.

---
## Apple iCloud (Digital Legacy)
- Add a Legacy Contact under Settings → Apple ID → Password & Security.
- Generate Access Key. Share with trusted contact.
- Executor must present death certificate.

## Google Inactive Account Manager
- Go to myaccount.google.com/inactive.
- Choose trusted contacts, select data sharing, and inactivity period.

## Facebook
- Add a Legacy Contact under Settings → Memorialization Settings.
- Legacy contact can manage memorialized profile.

## Instagram
- Submit memorialization or account removal request with death certificate.

## PayPal / Amazon
- Executor must contact customer support with legal documents.
