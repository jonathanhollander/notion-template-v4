# Master Checklist (Sample)

## Legal
- [ ] Will completed
- [ ] Executor named
- [ ] Power of Attorney

## Financial
- [ ] Bank accounts listed
- [ ] Subscriptions documented
- [ ] Insurance policies added

## Digital
- [ ] iCloud legacy set
- [ ] Google inactive account
- [ ] Password manager updated

## Medical
- [ ] Medications listed
- [ ] Final wishes documented

## Memories
- [ ] Ethical will written
- [ ] Photos uploaded
- [ ] Messages to loved ones drafted
