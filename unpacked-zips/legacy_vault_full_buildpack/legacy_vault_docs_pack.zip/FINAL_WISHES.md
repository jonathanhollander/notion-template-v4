# Final Wishes (Sample)

⚠️ Disclaimer: SAMPLE ONLY. Not legally binding in all states.

---
## Funeral
- Preferred: Cremation
- Service: Small private gathering

## Burial / Ashes
- Scatter ashes at sea.

## Music / Readings
- Song: "Imagine" by John Lennon
- Reading: Psalm 23

## Notes for Executor
These wishes express personal preferences, but executor should follow state law and resources available.
