# Ethical Will (Sample)

An Ethical Will passes on values, principles, and life lessons rather than property.

---
## SAMPLE CONTENT
To my family,  
I leave not only my belongings, but also the lessons of kindness, resilience, and integrity.  
May you live with compassion, pursue wisdom, and care for one another.

---
## Notes for User
- Write in your own voice.
- Include personal stories or values important to you.
