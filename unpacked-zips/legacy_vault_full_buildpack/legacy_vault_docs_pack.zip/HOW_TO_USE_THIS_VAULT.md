# How to Use This Vault (Sample)

---
## For the Owner
1. Fill in all SAMPLE placeholders with your real data.
2. Review legal and financial documents with professionals.
3. Update annually.

## For the Executor
1. Start with Executor Quick Sheet.
2. Follow Legal → Executor Tasks.
3. Access digital and financial guides.
