# Executor Quick Sheet (Sample)

⚠️ Disclaimer: SAMPLE ONLY. Executors should verify steps with an attorney.

---
## Day 1 Checklist
- Secure the home and assets.
- Obtain multiple certified death certificates.
- Notify close family members.

## Week 1 Checklist
- Notify employer of deceased.
- Begin funeral arrangements.
- Secure important documents (will, deeds, insurance).

## Month 1 Checklist
- Notify financial institutions.
- Close or transfer digital accounts.
- Begin estate inventory.

---
## Sample Contacts
- Lawyer: [SAMPLE NAME], [CONTACT]
- Accountant: [SAMPLE NAME], [CONTACT]
