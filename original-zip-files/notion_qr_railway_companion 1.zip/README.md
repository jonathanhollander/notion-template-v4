# Notion Companion App\nEmbed empathetic Companion messages in Notion.\n
