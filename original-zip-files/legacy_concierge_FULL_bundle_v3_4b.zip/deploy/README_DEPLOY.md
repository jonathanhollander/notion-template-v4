Use deploy_v3_4b.py with the split_yaml directory. Supports link_to_database blocks.
