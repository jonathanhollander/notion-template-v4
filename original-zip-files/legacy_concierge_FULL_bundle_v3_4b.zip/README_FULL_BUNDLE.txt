Legacy Concierge — FULL bundle v3.4b
- Renamed: Admin Cockpit→Builder’s Console, Executor View→Executor Guide, Family View→Family Guide
- New page: Preparation Hub (auto-linked to Preparation Progress DB)
- Tracker renamed/formalized as 'Preparation Progress (owner_progress)' database
- Deploy script supports link_to_database blocks by database name
