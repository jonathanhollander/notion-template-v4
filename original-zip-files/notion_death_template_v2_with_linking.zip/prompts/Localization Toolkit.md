# Localization Toolkit — Page Prompts

"Rewrite the page headers and callouts for [language], respecting punctuation, date formats, and name order. Keep the tone compassionate and clear."
