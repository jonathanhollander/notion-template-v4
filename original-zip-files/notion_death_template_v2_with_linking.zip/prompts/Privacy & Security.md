# Privacy & Security — Page Prompts

"Review this page for any sensitive fields. Suggest what to move into a password manager and where to add 2FA or restricted sharing."
