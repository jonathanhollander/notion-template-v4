# Digital Legacy — Page Prompts

"List the steps for Apple Digital Legacy, Google Inactive Account Manager, and Facebook memorialization. Create a checklist with links pulled from this page."
