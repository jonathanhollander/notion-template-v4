# Welcome & Orientation

- What to expect, how to go at your own pace.
- Link to Quick-Start Wizard and Master To-Do.
- Emotional reassurance: 'Even one step is progress.'
