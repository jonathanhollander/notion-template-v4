# Privacy & Security Guide

- Use Notion sharing carefully: Viewer vs Editor.
- Enable 2FA where possible.
- Avoid storing raw passwords in any Notion database.
