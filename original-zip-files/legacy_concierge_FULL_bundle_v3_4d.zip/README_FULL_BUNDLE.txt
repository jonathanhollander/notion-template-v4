Legacy Concierge — FULL bundle v3.4d
This is the definitive release-ready version.

Includes:
- All 17 letters seeded and polished.
- All pages & subpages with icons, covers, compassionate descriptions.
- Consistent disclaimers across sensitive pages and letters.
- Expanded diagnostics with coaching phrasing.
- Acceptance criteria for key pages (Preparation Hub, Executor Guide, Family Guide, Letters, Living Will, Medical, Insurance, Closure).
- Sample content seeded in Memories, Life Story, Financial Accounts, Preparation Progress DB.
- Builder’s Console with diagnostics snapshot, quick links, and reassurance line.
