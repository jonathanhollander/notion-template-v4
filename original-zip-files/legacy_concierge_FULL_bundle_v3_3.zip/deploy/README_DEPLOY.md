Use deploy_v3_3.py with the split_yaml directory.
