# Letter to Loved One

## Letter Template
Dear [Name],

[One memory we shared...]

[One lesson you taught me or I hope to pass on...]

[One hope for your future...]

With love,
[Your Name]
