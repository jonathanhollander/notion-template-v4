# Backup & Offline Pack

- Export: File → Export → PDF/Markdown/CSV.
- Print: Will, directives, key contacts, executor checklist.
- Assemble a physical folder for heirs.
