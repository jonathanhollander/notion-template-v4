# Facebook Instagram Memorialization

- Facebook: Set a legacy contact; request memorialization with proof.
- Instagram: Request memorialization or removal with proof of passing.
