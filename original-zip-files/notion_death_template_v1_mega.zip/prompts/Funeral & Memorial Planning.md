# Funeral & Memorial Planning — Page Prompts

"Using preferences and the music/readings tables, generate a 1-page memorial program (order of service) for printing. Include times, names, and short descriptions."
