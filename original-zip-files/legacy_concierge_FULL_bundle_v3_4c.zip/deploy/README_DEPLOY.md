Use deploy_v3_4c.py with split_yaml directory.
