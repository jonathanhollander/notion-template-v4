Legacy Concierge — FULL bundle v3.4c
- Incorporates v3.4a + v3.4b improvements (letters, disclaimers, diagnostics, Preparation Hub, renames).
- Executor/Family pages polished with specific compassionate wording.
- Letters polished with uniform structure and closings.
- Preparation Hub seeded DB rows show progress immediately.
- Diagnostics rephrased as coaching.
- Disclaimers consistently applied.
- Closure page ceremonial and reassuring.
- Builder’s Console includes final reassurance line.
- Icons/covers replaced with real Unsplash links.
