Legacy Concierge — FULL bundle v3.4e
This is the definitive, release-ready version.

Includes:
- All 17 letters seeded, polished and uniform.
- Every page and subpage with icons, covers, and role-specific compassionate descriptions.
- Disclaimers applied consistently to executor/legal/financial pages and letters.
- Diagnostics rules expanded to enforce disclaimers, family tone, seed data presence.
- Acceptance criteria expanded to cover all ~60 pages.
- Sample data seeded across executor DBs (Insurance, Taxes, Property, Vehicles) as well as Memories, Life Story, Financial Accounts, Preparation Progress.
- Builder’s Console with linked Diagnostics view, quick links, and reassurance line.
