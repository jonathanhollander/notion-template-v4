# Scheduled Letters
Fill rows; automation sends on the date.
