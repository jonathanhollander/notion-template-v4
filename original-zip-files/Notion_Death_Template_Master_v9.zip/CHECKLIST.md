# Notion Death Template — Master v9 (Feature Checklist)
Includes pages, QR packs (Top‑10 & Complete), localization kit, Pages Menu DB, Scheduled Letters, Calendar Reminders, conversion extras, scripts, and starter code.
