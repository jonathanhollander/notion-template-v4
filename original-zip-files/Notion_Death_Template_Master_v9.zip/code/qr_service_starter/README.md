Starter for selling static QR bundles (Top‑10 / Complete).
