# Notion OAuth QR Uploader (Skeleton)
Stripe → OAuth (select top Menu) → crawl → direct upload images → create two QR pages.
