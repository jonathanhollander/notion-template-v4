# Welcome Script (90s)
Calm, compassionate tone.
