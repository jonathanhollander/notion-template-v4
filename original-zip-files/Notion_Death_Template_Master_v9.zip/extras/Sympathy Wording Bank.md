# Sympathy Wording (20)
Short, sincere phrases.
