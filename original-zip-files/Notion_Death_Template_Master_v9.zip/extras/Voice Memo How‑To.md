# Voice Memo How‑To
Capture audio memories; drag into Notion.
