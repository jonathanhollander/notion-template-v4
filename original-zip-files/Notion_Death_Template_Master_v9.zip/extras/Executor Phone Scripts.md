# Phone Scripts
Insurance, bank, HR scripts with placeholders.
