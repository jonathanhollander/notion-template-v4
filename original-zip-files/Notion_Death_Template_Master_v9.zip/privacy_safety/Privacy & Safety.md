# Privacy & Safety
Invite-only, never public. QRs are shortcuts.
