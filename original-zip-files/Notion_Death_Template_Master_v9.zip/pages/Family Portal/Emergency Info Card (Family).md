# Emergency Info Card (Family)
One‑page summary.
