# How this works (for family)
Invite‑only access. Scan or click.
