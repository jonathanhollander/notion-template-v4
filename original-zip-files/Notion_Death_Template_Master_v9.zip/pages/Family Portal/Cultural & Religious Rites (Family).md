# Cultural & Religious Rites
Plain‑language guidance.
