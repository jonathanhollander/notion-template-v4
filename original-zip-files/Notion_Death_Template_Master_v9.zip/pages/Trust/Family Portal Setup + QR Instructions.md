# Family Portal Setup + QR Instructions
Invite‑only. QR is just a shortcut.
