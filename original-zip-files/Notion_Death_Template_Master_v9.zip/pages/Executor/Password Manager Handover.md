# Password Manager Handover
Instructions only—no secrets.
