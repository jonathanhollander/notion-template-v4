# Digital Legacy
Apple/Google/Facebook steps.
