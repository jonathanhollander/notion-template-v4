# First 24–72 Hours
Immediate, calm checklist.
