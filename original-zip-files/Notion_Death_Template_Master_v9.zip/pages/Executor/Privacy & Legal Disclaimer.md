# Privacy & Legal Disclaimer
We guide; not legal advice.
