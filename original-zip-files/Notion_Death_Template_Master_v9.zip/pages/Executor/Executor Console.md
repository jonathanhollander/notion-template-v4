# Executor Console
Hub for time‑critical steps.
