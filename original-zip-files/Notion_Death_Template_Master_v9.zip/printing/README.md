Use qr_bulk_generator.py to generate 3×4 PDF sheet.
