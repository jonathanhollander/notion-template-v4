# Menu DB → Gallery view; show Name + Icon; hide tech columns.
