Translate with cultural sensitivity. Output English + Translation + Notes per paragraph.
