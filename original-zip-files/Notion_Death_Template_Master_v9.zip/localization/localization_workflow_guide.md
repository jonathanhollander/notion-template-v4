# Localization Workflow
1) Export English master
2) Translate
3) Replace page text.
