# Obituary Poetic

## Poetic Obituary Template
Open with an image or metaphor tied to the person's essence. 
Weave in 3–4 short vignettes (30–60 words each) that reveal character, love, and place. Close with a gentle thanks.
