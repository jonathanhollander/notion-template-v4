# Changelog & Version Notes

- 2025-08-23: Initial consolidated build. Added 30+ pages and CSVs.
- Use this file to log future improvements.
