# Apple Digital Legacy Guide

Step-by-step for setting a Legacy Contact in Apple ID:
1) Settings → [Your Name] → Password & Security → Legacy Contact.
2) Add contact, share access key.
3) Print and store the QR access code in Document Locator.
