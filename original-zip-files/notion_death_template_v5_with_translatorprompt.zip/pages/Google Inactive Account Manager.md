# Google Inactive Account Manager

1) Visit Google's Inactive Account Manager.
2) Set timeout period and trusted contacts.
3) Choose which data is shared and whether to delete account.
