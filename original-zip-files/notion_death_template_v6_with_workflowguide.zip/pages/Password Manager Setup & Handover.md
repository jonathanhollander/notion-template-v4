# Password Manager Setup & Handover

- Choose a manager with emergency access (e.g., 1Password, Bitwarden).
- Store credentials there; in Notion, keep only references and recovery steps.
- Document Emergency Kit location in Document Locator.
