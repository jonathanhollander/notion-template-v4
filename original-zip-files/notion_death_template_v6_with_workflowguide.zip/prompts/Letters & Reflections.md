# Letters & Reflections — Page Prompts

**How to use:** Paste ABOVE database.

**Daily micro-prompts (rotate):**
- "Today I miss..."
- "A time we laughed so hard was..."
- "One lesson they taught me is..."
- "If they could advise me today, they'd say..."

**Letter Prompt:**
"Write a letter to [recipient]. Use 2–4 short paragraphs. Include one memory, one lesson, and one hope for their future."
