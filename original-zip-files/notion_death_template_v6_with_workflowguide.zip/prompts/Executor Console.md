# Executor Console — Page Prompts

**How to use:** Paste ABOVE database.

"Summarize the top 5 critical tasks for the executor from this database. Output as a numbered list with links to the relevant pages."
