Legacy Concierge — FULL bundle v3.4f
This is the definitive release-ready version.

- Gradient diamond icons (SVG + PNG, sage, peach, beige, gray).
- Consistent Unsplash covers applied across all pages.
- Compassionate, role-specific descriptions for all ~60 pages.
- Letters standardized across 17 seeded entries.
- Disclaimers applied consistently across all executor/legal/financial pages and letters.
- Expanded diagnostics enforce disclaimers, tone separation, and DB seeds.
- Acceptance criteria written for all pages.
- Sample data seeded across all DBs (Insurance, Taxes, Property, Vehicles, Memories, Life Story, Keepsakes, etc.).
- Builder’s Console includes live Diagnostics DB view with quick links.
