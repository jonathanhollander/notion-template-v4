# Localization Toolkit

- Phrase bank: 'Back to Checklist' → localized equivalent.
- Date formats: MDY vs DMY.
- Name order and honorifics.
