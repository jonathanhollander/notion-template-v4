# First 24–72 Hours — Page Prompts

"Create a step-by-step plan for the first 24, 48, and 72 hours using the rows below. Keep instructions concise and link to referenced pages."
