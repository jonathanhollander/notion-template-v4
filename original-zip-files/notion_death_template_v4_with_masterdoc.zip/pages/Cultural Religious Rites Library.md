# Cultural Religious Rites Library

- Provide optional readings, prayers, or secular alternatives.
- Keep language inclusive and editable.
