# Obituary Formal

## Formal Obituary Template
- Full Name:
- Age:
- Date & Place of Passing:
- Biography Highlights (education, career, service):
- Immediate Family:
- Service Details (date/time/place):
- Memorial Donations (optional):
