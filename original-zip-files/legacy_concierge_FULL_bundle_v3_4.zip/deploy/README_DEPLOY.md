Use deploy_v3_4.py with the split_yaml directory. Dry-run first.
