# leemiumZ Style Guide

This guide explains how to apply icons, covers, and assets in Notion.
