# How to use this template

1. Import CSVs in **Databases/** as Notion databases.
2. Tailor the example pages under **Prefilled Example Pages/**.
3. Create relations between **Tasks** and **Documents** (optional).
4. Share individual pages with trusted people and use header images/icons for clarity.
