# FAQ

**Is this legal advice?**  
No. This is an organizational template only.

**Can I import everything at once?**  
Yes, drag the folder into a Notion page, or import piece-by-piece.

**How do I link databases?**  
After importing CSVs, create relation properties in Notion and connect entries.
