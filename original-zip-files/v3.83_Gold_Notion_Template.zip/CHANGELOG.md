# CHANGELOG (excerpt)
- v3.83 Gold
  - Finalized databases with prefilled examples
  - Added premium icon & header asset set
  - Expanded guidance pages (styling, FAQ, localization drafts)
  - Included sample documents (Will, Letters, Obituaries, Legacy Letter)
