# Sample Obituary — Version B (Example)

[Full Name] embodied kindness and curiosity. They leaves behind [Family], who will celebrate their life at [Location] on [Date/Time]. Memorial donations: [Charity].
