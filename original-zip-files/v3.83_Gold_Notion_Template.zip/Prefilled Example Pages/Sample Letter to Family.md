# Sample Letter to Family (Example)

Dear Family,

I wrote this template so you have clarity and comfort. You’ll find key documents in the **Documents** database and important contacts in **People**. Please prioritize safety, legal filings, and insurance notifications.

With love,
[Your Name]
