# Sample Obituary — Version A (Example)

[Full Name], [Age], of [City], passed away on [Date]. They are survived by [Family]. A service will be held at [Location] on [Date/Time]. In lieu of flowers, contributions may be made to [Charity].
