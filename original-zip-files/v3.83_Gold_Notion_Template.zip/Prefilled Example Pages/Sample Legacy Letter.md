# Sample Legacy Letter (Example)

To those I love,

Here are stories, values, and hopes I want to pass on. Remember to look after one another, and invest in community and learning. Please support [cause/charity] that meant a lot to me.
