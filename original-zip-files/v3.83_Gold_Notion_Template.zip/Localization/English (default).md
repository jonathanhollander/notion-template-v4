# English (default)

This template is written in English. Duplicate pages and translate content for other locales.
