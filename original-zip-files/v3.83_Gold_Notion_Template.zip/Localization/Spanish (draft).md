# Español (borrador)

Duplique páginas y traduzca el contenido clave (Documentos, Cuentas, Personas, Tareas). Añada notas legales locales.
