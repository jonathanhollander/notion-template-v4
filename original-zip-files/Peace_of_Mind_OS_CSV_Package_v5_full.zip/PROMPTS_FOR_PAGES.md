# Prompts for Pages

- Legacy Letters: Combine all drafts into one final document.
- Obituary Drafts: Produce two alternative obituaries...
