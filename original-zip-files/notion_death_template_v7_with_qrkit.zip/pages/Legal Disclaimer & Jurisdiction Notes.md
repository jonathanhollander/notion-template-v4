# Legal Disclaimer & Jurisdiction Notes

This is not legal advice. Laws vary by jurisdiction. Consult an attorney to validate documents and plans.
