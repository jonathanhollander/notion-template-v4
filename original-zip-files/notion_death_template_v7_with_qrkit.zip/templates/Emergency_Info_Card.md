## Emergency Info Card (Copy Text)

Front:
- Legacy Planning — Notion
- QR: Shared Portal (View‑Only)
- Executor: [Name, Phone]
- Note: No passwords on this card

Back:
- 1) Call attorney
- 2) Locate will in safe
- 3) Open Executor Console
- Backup URL: [short.link/legacy]
- Printed: [YYYY‑MM‑DD]