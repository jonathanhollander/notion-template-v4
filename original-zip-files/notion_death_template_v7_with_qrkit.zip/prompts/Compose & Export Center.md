# Compose & Export Center — Page Prompts

"Combine the selected Letters and Reflections entries into a single 'Legacy Booklet' summary under 1,000 words. Organize by recipient, then theme. Output in clean Markdown for export to PDF."
