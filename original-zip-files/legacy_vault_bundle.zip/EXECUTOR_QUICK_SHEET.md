# Executor Quick Sheet (Print-Friendly)

**Deceased:** ______________________    **DOB:** ________    **DOD:** ________

## First 5 Calls
1. Funeral Home: __________________  Phone: ___________
2. Estate Attorney: _______________  Phone: ___________
3. Primary Executor: ______________  Phone: ___________
4. Bank (estate account setup): ____ Phone: ___________
5. Employer / HR (if applicable): __ Phone: ___________

## Documents & Locations
- Will / Trust: ______________________________________
- IDs (driver’s license, passport): ___________________
- Deeds / Titles: _____________________________________
- Insurance Policies: _________________________________
- Safe Deposit Box / Password Manager: ________________

## Accounts (See databases for details)
- Banks: _____________________________________________
- Credit Cards: ______________________________________
- Investment/Retirement: _____________________________

## Immediate Tasks (Day 1)
- ☐ Secure residence and documents
- ☐ Notify close family
- ☐ Engage funeral home
- ☐ Locate will/trust and attorney details

## Within Week 1
- ☐ Order 10–12 certified death certificates
- ☐ Notify banks/insurers; freeze as needed
- ☐ Cancel or forward mail

## Notes
_______________________________________________________
