# Ethical Will (Template)

> An ethical will shares values, lessons, and hopes (not legal instructions).

## My Core Values
- Integrity: ____________________________________________
- Compassion: __________________________________________
- Curiosity: ___________________________________________

## Principles I Lived By
- ______________________________________________________

## Lessons I Hope You Remember
- About family: ________________________________________
- About work: __________________________________________
- About money: _________________________________________
- About friendship: ____________________________________

## Hopes for the Future
- ______________________________________________________

## Gratitude
- I am grateful for ____________________________________

— [Your Name], [Date]
